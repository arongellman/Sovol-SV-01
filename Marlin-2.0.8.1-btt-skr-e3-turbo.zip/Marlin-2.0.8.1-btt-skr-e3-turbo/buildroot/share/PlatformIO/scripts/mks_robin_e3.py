#
# buildroot/share/PlatformIO/scripts/mks_robin_e3.py
#
import marlin
marlin.prepare_robin("0x08005000", "mks_robin_e3.ld", "Robin_e3.bin")
